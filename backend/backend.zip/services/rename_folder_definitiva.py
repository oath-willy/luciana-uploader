
async def rename_folder(old_prefix: str, new_prefix: str, container: str = "bronze"):
    if is_adls_container(container):
        fs_client = get_adls_filesystem(container)

        if not old_prefix.endswith("/"):
            old_prefix += "/"
        if not new_prefix.endswith("/"):
            new_prefix += "/"

        # ✅ Controllo affidabile su ADLS
        print(f"🔍 DEBUG — verifica esistenza '{new_prefix}'")
        dir_client = fs_client.get_directory_client(new_prefix.rstrip("/"))
        try:
            await dir_client.get_properties()
            print(f"⛔️ Conflitto: directory '{new_prefix}' esiste già")
            raise HTTPException(status_code=400, detail=f"Conflitto: la cartella '{new_prefix}' esiste già")
        except Exception as e:
            print(f"⚠️ Eccezione durante controllo esistenza cartella: {repr(e)}")
            if "StatusCode=404" in str(e) or "ResourceNotFoundError" in str(type(e)):
                print("✅ Nessuna directory esplicita trovata")
            else:
                raise HTTPException(status_code=500, detail=f"Errore controllo esistenza: {str(e)}")

        print("✅ Procedo con rinomina.")

        try:
            await fs_client.create_directory(new_prefix)
        except Exception:
            pass

        paths = []
        async for path in fs_client.get_paths(path=old_prefix, recursive=True):
            paths.append(path.name)

        for src_path in sorted(paths, reverse=True):
            relative = src_path[len(old_prefix):].lstrip("/")
            dest_path = f"{new_prefix}{relative}".replace("//", "/")
            file_client = fs_client.get_file_client(src_path)
            try:
                await file_client.rename_file(f"{fs_client.file_system_name}/{dest_path}")
            except Exception as e:
                print(f"❌ Errore rename {src_path} → {dest_path}: {e}")
                raise HTTPException(status_code=500, detail=f"Errore rename {src_path}: {str(e)}")

        try:
            await fs_client.get_directory_client(old_prefix.rstrip("/")).delete_directory()
        except Exception as e:
            print(f"⚠️ Impossibile eliminare directory {old_prefix}: {e}")

    else:
        container_client = get_blob_container_client(container)
        async for blob in container_client.list_blobs(name_starts_with=old_prefix):
            old_blob = container_client.get_blob_client(blob.name)
            new_name = blob.name.replace(old_prefix, new_prefix, 1)
            new_blob = container_client.get_blob_client(new_name)
            if await new_blob.exists():
                raise HTTPException(status_code=400, detail="Esiste già una cartella con questo nome.")
            await new_blob.start_copy_from_url(old_blob.url)
            await old_blob.delete_blob()
