// AdminDashboardPage.tsx - fix per Mantine v8 compatibile
import {
  IconHome2,
  IconSettings,
  IconUser,
  IconFileAnalytics,
  IconLock,
  IconDatabaseImport,
} from '@tabler/icons-react';
import {
  AppShell,
  AppShellNavbar,
  NavLink,
  Code,
  ScrollArea,
  Text,
  rem,
  Box,
  Stack,
} from '@mantine/core';

export default function AdminDashboardPage() {
  return (
    <AppShell
      padding="md"
      navbar={{
        width: 300,
        breakpoint: 'sm',
        collapsed: { mobile: false },
      }}
    >
      <AppShellNavbar p="md">
        <Box mb="md">
          <Text fw={700} size="lg">
            Admin Panel
          </Text>
        </Box>

        <ScrollArea type="auto" style={{ flex: 1 }}>
          <Stack gap="xs">
            <NavLink label="Home" leftSection={<IconHome2 size={18} />} />
            <NavLink label="Users" leftSection={<IconUser size={18} />} />

            <NavLink label="Reports" leftSection={<IconFileAnalytics size={18} />}>
              <NavLink label="Monthly" pl="md" />
              <NavLink label="Annual" pl="md" />
            </NavLink>

            <NavLink label="Database" leftSection={<IconDatabaseImport size={18} />}>
              <NavLink label="Imports" pl="md" />
              <NavLink label="Exports" pl="md" />
            </NavLink>

            <NavLink label="Security" leftSection={<IconLock size={18} />} />
            <NavLink label="Settings" leftSection={<IconSettings size={18} />} />
          </Stack>
        </ScrollArea>

        <Box mt="md">
          <Code fw={700}>v1.0.0</Code>
        </Box>
      </AppShellNavbar>

      <AppShell.Main>
        <Text size="lg">Benvenuto nella dashboard amministrativa!</Text>
      </AppShell.Main>
    </AppShell>
  );
}
